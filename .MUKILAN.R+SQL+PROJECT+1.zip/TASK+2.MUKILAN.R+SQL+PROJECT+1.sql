#TASK 2

#Perform read operation on the designed table created in the above task.
use Travego;
show tables;
# Question A
# A. How many female passengers traveled a minimum distance of 600 KMs? 

select count(gender)as no_of_female from passenger where Gender ="f" and Distance>=600;

# Question B
# B. Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus. 

select * from passenger where distance>500 and bus_type="sleeper";

# Question C
# C. Select passenger names whose names start with the character 'S'.(2 marks)

select *  from passenger where passenger_name like"s%";

# Question D
# D. Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,Destination City, Bus type, and Price in the output. (3 marks)

select  p.passenger_name ,p.boarding_city, p.Destination_city ,p.bus_type ,pr.price from passenger p join price pr on p.bus_type=pr.bus_type and p.Distance=pr.Distance;

# Question E 
# E. What are the passenger_name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus? (4 marks)

select * from passenger;
select p.passenger_name,pr.price from passenger p,price pr where p.distance=pr.distance and p.bus_type like "%sitting%" and p.distance=1000;


# Question F
# F. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji? (5marks)

select * from passenger;
select Bus_type,price from price pr where pr.distance=(select distance from passenger where passenger_name ='Pallavi') ;




# Question G
# G. Alter the column category with the value "Non-AC" where the Bus_Type is sleeper (2 marks)
# in the above queries to avoid warning using the safe_update. 

SET SQL_SAFE_UPDATES = 0;
update passenger
SET Category ="Non_AC" where bus_type="Sleeper";

#After updated the category we want to check the table.
select * from passenger;


# 	QUESTION H
# H. Delete an entry from the table where the passenger name is Piyush and commit this change in the database. (1 mark)
delete  from passenger where passenger_name= "piyush";
commit;
# After delete the passenger name and check it.
select * from passenger;

# Question I
# I. Truncate the table passenger and comment on the number of rows in the table (explain ifrequired). (1 mark)

truncate passenger;
# The truncate will delete the rows and retain the data structure.
# check the table
select * from passenger;

# Question J
# J. Delete the table passenger from the database. (1 mark)

drop table passenger;
# After deleting the passenger table and check the tables:
show tables;

